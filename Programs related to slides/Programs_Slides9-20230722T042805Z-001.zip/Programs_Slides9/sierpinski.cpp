#include<simplecpp>


void draw_sierpinski (int n, double p1x, double p1y, double p2x, double p2y, double p3x, double p3y)
{
Line l1(p1x,p1y,p2x,p2y); l1.imprint(); // the lines of the equil. triangle
Line l2(p1x,p1y,p3x,p3y); l2.imprint();
Line l3(p2x,p2y,p3x,p3y); l3.imprint();

if (n > 0)
{
    double q1x = (p1x + p2x)/2; double q1y = (p1y + p2y)/2; // recursive calls to three outer triangles
    double q2x = (p1x + p3x)/2; double q2y = (p1y + p3y)/2;
    double q3x = (p2x + p3x)/2; double q3y = (p2y + p3y)/2;
    draw_sierpinski(n - 1, p1x, p1y, q1x, q1y, q2x, q2y);
    draw_sierpinski(n - 1, p2x, p2y, q1x, q1y, q3x, q3y);
    draw_sierpinski(n - 1, p3x, p3y, q2x, q2y, q3x, q3y);
}
}

main_program{
int n;
double p1x,p1y,p2x,p2y,p3x,p3y;

cout << "Enter the level of recursion: "; cin >> n;

initCanvas ("Sierpinski's triangle",500,500); // inbuilt function to create a new window

p1x = p1y = 100;
p2x = 400; p2y = 100;
p3x = 250; p3y = 100 + 150*sqrt(3);
draw_sierpinski (n,  p1x,  p1y,  p2x,  p2y,  p3x,  p3y);
wait (15);
}
