#include<iostream>
using namespace std;

int rec_virahanka (int n)
{
    if ( n == 1) return 1;
    if (n == 2) return 2;
    return rec_virahanka(n-1) + rec_virahanka(n-2);
}

int virahanka (int n)
{
    if ( n == 1) return 1;
    if (n == 2) return 2;
    int prev = 1, curr = 2,val;

    for(int i = 0; i < n-2;i++)
    {
        val = prev + curr;
        prev = curr;
        curr = val;
    }
    return val;
}

int main()
{
    int n,z;
    cout << "enter the value of n: ";
    cin >> n;

    z = rec_virahanka(n);
    cout << "z = " << z;
    z = virahanka(n);
    cout << " z = " << z;
}
