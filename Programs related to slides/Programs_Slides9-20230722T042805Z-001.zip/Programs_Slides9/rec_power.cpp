#include<iostream>
using namespace std;

float rec_power (float x, int n) {
// n should be a non-negative integer
if (n == 0) return 1; // base case 1
if (n == 1) return x; // base case 2
float temp = rec_power(x,n/2); // evaluate x^(n/2)
if (n%2 == 0) return temp*temp; // n is even
else return temp*temp*x; // n is odd
}

int main()
{
    float x,z; int n;

    cout << "enter x and n: "; cin >> x >> n;

    z = rec_power(x,n);
    cout << "z = " << z;
}
