#include<simplecpp>

main_program{
int n;
double p,q,r,s;
p = q = r = s = 0.0;

cout << "Enter the number of points: "; cin >> n;

initCanvas ("Fitting a line to given data",500,500); // inbuilt function to create a new window

Circle pt(0,0,0); // this is an object which will be used to draw a small circle around each clicked point

for (int i = 0; i < n; i++)
{
    int cPos = getClick(); // ask the user to click on a point
    double x = cPos/65536.0; // x coordinate of the point
    double y = cPos%65536; // the point's y coordinate
    pt.reset(x,y,3); // draw a small circle around that point
    pt.imprint(); // we want to retain that circle even when we move pt for getting other points

    p += x*x; q += x; r += x*y; s += y;
}
double m = (n*r-q*s)/(n*p-q*q); // calculate slope
double c = (p*s - q*r)/(n*p - q*q); // calculate intercept
Line l (0,c,500,500*m+c); // draw the line
wait (15);
}
