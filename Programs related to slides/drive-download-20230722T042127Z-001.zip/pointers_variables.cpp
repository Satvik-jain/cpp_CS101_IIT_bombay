#include<iostream>
using namespace std;

int main(){
int n = 33; int *p = &n;
cout << "n = " << n << " &n = " << &n << " p = " << p << endl;
cout << "*p = " << *p;
}
