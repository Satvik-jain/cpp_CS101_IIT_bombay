#include<iostream>
using namespace std;

int main () {
	int n=3;
	// reference variable below � needs to be initialized
	// during declaration
	int& r = n;
	cout << n << " "  << r << endl;
r = 2; // assigns this value to r and n both
cout << n << " " << r << endl;
}
