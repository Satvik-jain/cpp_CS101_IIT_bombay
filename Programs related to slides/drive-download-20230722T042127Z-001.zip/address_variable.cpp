#include<iostream>
using namespace std;

int main(){
int n=2;
cout << n << endl; // prints the value of n
cout << &n; // prints the address of n
}
