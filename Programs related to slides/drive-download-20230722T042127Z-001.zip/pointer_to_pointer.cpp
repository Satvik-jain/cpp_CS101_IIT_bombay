#include<iostream>
using namespace std;

int main(){
	int a = 10;
	int *pa = &a;
	int **ppa = &pa;
	**ppa = 50;
	cout << "a = " << a << " *pa = " << *pa << " **ppa = " << **ppa;
}
