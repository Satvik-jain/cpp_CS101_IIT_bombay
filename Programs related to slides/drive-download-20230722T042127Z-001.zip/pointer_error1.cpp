#include<iostream>
using namespace std;

int main(){
double q;
int *p = &q; // this will produce a compilation error
}

