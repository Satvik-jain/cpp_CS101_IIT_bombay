#include<iostream>
using namespace std;

void swapRef (int& a, int& b)
{
    int temp = a;
    a = b;
    b = temp;
    return;
}

void swapPointers (int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
    return;
}

void swapValue (int a, int b)
{
    int temp = a;
    a = b;
    b = temp;
    return;
}

int main ()
{
    int x = 10, y = 20;

    swapRef(x,y);
    cout << x << ","<<y << endl;

    swapPointers(&x,&y);
    cout << x << ","<<y << endl;

    swapValue(x,y);
    cout << x << ","<<y << endl;

    return 0;
}
