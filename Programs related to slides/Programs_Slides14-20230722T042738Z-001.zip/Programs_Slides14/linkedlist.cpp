#include <iostream>
using namespace std;

struct node
{
	int data;
	node *next;
};

node* createLinkedList ()
{
	node* header = new node;
	header->data = 0;
	header->next = NULL;
	return header;
}

void appendNode (node* header, int dataval)
{
	node *q = header, *r;	

	node *p = new node;
	p->data = dataval;
	p->next = NULL;

	while (q!= NULL)
	{
		r = q;
		q = q->next;
	}
	r->next = p;
}

void displayList (node* header)
{
	node *q = header;

	if (header == NULL) { cout << "This list does not exist"; return;}
	if (header->next == NULL) { cout << "The list is empty"; return;} 

	cout << endl;
	while (q != NULL) {
		if (q!=header) cout << q->data << " ";
		q = q->next;
	}
}

bool deleteLastNode (node* header)
{
	node *curr = header, *prev;

	if (header->next == NULL) return false;
	while (curr->next != NULL)
	{
		prev = curr;
		curr = curr->next;
	}
	prev->next = NULL;
	delete curr;

	return true;
}

void deleteLinkedList (node *header)
{
	do
	{
		bool flag = deleteLastNode (header);
		if (flag == false) break;
		displayList (header);
	} while (true);

	delete header;
	cout << "deleting the header node: no more operations can be performed on this list";
}

void reverseLinkedList(node *header)
{
	if (header == NULL) return;
        // Initialize current, previous and next pointers
        node* curr = header->next;
        node *prev = NULL, *next = NULL;

        while (curr != NULL) {
            // Store next
            next = curr->next;
            // Reverse current node's pointer
            curr->next = prev;
            // Move pointers one position ahead.
            prev = curr;
            curr = next;
        }
        header->next = prev;
}


int main()
{
	node *header;
	int choice, dataval;

	header = createLinkedList();

	do
	{
		cout << "do want to append a node with some data to the linkedlist? (0: no, anything else: yes)";
		cin >> choice;
		if (choice  == 0) break;

		cout << "enter data:";
		cin >> dataval;

		appendNode(header,dataval);
	}while (1);

	displayList(header);

	reverseLinkedList(header);
	displayList(header);

	do
	{
		bool flag = deleteLastNode (header);
		if (flag == false) break;
		displayList (header);
	} while (true);
}
