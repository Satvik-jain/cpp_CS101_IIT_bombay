#include <iostream>
using namespace std;

struct monomial {
	float coeff;
	unsigned int degree;
};


monomial* add_polynomials(monomial* p1, monomial* p2, int n1,int n2, int& n3){
        int cp1, cp2, cp3;
        monomial *p3 = new monomial[n1+n2]; //dynamic memory allocation for an array of structures
        cp1 = cp2 = cp3 = 0;

        while (cp1 < n1 && cp2 < n2){
                if (p1[cp1].degree < p2[cp2].degree){
                        p3[cp3].degree = p1[cp1].degree;  p3[cp3].coeff = p1[cp1].coeff; cp3++; cp1++;
                }

                else if (p2[cp2].degree < p1[cp1].degree){
                        p3[cp3].degree = p2[cp2].degree;  p3[cp3].coeff = p2[cp2].coeff; cp3++; cp2++;
                }
                else{
                        p3[cp3].degree = p2[cp2].degree;  
p3[cp3].coeff = p1[cp1].coeff+p2[cp2].coeff; cp3++; cp2++; cp1++;
                }
        } // close while

        while (cp1 < n1){
                p3[cp3].degree = p1[cp1].degree;  p3[cp3].coeff = p1[cp1].coeff; cp3++; cp1++;
        }
        while (cp2 < n2){
                p3[cp3].degree = p2[cp2].degree;  p3[cp3].coeff = p2[cp2].coeff; cp3++; cp2++;
        }

        n3 = cp3;
        return p3;
}


void display_poly(monomial *p, int n)
{
        for(int i = 0; i < n;i++)
        {
                cout << p[i].coeff << "*x^" << p[i].degree;
                if (i < n-1) cout << " + ";
        }
}

int main(){
        int n1, n2,n3,i;
        cout << "enter the number of terms of the first and second polynomial: ";
        cin >> n1 >> n2;
        monomial *p1, *p2, *p3;
        
	p1 = new monomial[n1];
        p2 = new monomial[n2];
        
	cout << "enter the terms of the first polynomial in increasing order: " << endl;
        for(i=0;i<n1;i++) { cout << "enter the coefficient and degree of the next term: " << endl; 
	cin >> p1[i].coeff >> p1[i].degree;}
        
	cout << "enter the terms of the second polynomial in increasing order: " << endl;
        for(i=0;i<n2;i++) { cout << "enter the coefficient and degree of the next term: " << endl; 
	cin >> p2[i].coeff >> p2[i].degree;}
        
	p3 = add_polynomials(p1,p2,n1,n2,n3);
        display_poly(p3,n3);
}
