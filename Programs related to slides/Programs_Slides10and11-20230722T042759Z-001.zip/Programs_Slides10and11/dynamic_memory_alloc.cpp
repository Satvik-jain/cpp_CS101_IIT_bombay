#include <iostream>
using namespace std;

int** allocate1_2d (int n1, int n2)
{
	int i,j;

	int **A = new int*[n1]; // array of n1 int* variables

	for(i=0;i<n1;i++){
		A[i] =  new int [n2]; // array of n2 int variables
	}

	for(i=0;i<n1;i++)
	{
		for(j=0;j<n2;j++)
		{
			A[i][j] = i+j;
			cout << A[i][j] << " ";
		}
		cout << endl;
	}

	return A;
}

void deallocate1_2d (int **A, int n1, int n2){
for(int i=0;i<n1;i++) delete A[i];
delete [] A;
}


int main()
{
	int i,j;
	int n1 = 4, n2 = 5;
	int **A;

	A = allocate1_2d(n1,n2);
	deallocate1_2d(A,n1,n2); 
}
