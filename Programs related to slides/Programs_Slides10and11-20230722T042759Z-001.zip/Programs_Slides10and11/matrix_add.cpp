#include<iostream>

void matrix_add (int A[][3], int B[][3], int C[][3], int n1, int n2)
{
    int i,j;

    for(i=0;i<n1;i++)
    {
        for(j=0;j<n2;j++)
        {
            C[i][j] = A[i][j]+B[i][j];
        }
    }
}

int main()
{
    int A[2][3], B[2][3], C[2][3];

    matrix_add(A,B,C,2,3);
}
