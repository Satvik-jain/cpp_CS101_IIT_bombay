#include<simplecpp>
#include<cstdlib>
#define SIGLENGTH 100

main_program{
float signal[SIGLENGTH],noisy_signal[SIGLENGTH], restored_signal[SIGLENGTH],noiseval;
int i, leftindex, rightindex, j;
const int windowRadius = 7;

initCanvas ("Signal Smoothing",500,500); // inbuilt function to create a new window
Circle pt(0,0,0);

for(i = 0; i < SIGLENGTH; i++)
{
    signal[i] = i;
    noiseval = 15*float(rand()-RAND_MAX/2)/RAND_MAX;
    noisy_signal[i] = signal[i] + noiseval;
    pt.reset(i+250,noisy_signal[i]+250,1); // draw a small circle around that point
    pt.imprint();
}

wait(2);

for(i = 0; i < SIGLENGTH; i++)
{
    leftindex = max(0,i-windowRadius);
    rightindex = min(SIGLENGTH-1,i+windowRadius);

    // code for the averaging operation
    float avg = 0.0;
    for (j=leftindex; j <= rightindex; j++)
    {
        avg += noisy_signal[j];
    }
    avg /= (rightindex-leftindex+1);
    restored_signal[i] = avg;

    pt.reset(i+250,restored_signal[i]+250,1); // draw a small circle around that point
    pt.imprint();
}

wait(10);
}
