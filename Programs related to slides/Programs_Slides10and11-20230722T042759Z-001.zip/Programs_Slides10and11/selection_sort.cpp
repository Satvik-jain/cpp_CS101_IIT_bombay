#include<simplecpp>

void swap (float *a, float *b)
{
    float temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

int argmax (float *marks, int L)
{
	int maxindex = 0;
	for(int j=1; j<L; j++){
		// update the index if a larger element is found
		if(marks[maxindex] < marks[j]) maxindex = j;
	}
	return maxindex;
}


void selection_sort (float *data, int n)
{
    for(int i=n; i>1;i--)
    {
        int maxindex = argmax(data,i); // get the maximum of the first i elements
        swap(&data[maxindex],&data[i-1]); // refer to earlier slides for this!
        // at this point, data[i-1] will be in the correct position for a sorted array
    }
}


main_program
{
    float A[100];
    int i,n;
    cout << "Enter the number of numbers: "; cin >> n;

    for (i= 0; i < n; i++)
    {
        cout << endl << "Enter the next number: ";
        cin >> A[i];
    }

    cout << endl << "The unsorted array is: " << endl;
    for (i= 0; i < n; i++)
    {
        cout << A[i] << " ";
    }


    selection_sort(A,n);
    cout << endl << "The sorted array is: " << endl;
    for (i= 0; i < n; i++)
    {
        cout << A[i] << " ";
    }
}
