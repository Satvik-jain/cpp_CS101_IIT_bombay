#include<simplecpp>

void swap (float *a, float *b)
{
    float temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

void bubble_sort(float *A, int n)
{
    int i, j;
    for (i = 0; i < n - 1; i++)
    {
        // Last i elements are already in place
        for (j = 0; j < n - i - 1; j++)
        {
            if (A[j] > A[j + 1])
                swap(&A[j], &A[j + 1]);
        }
    }
}


main_program
{
    float A[100];
    int i,n;
    cout << "Enter the number of numbers: "; cin >> n;

    for (i= 0; i < n; i++)
    {
        cout << endl << "Enter the next number: ";
        cin >> A[i];
    }

    cout << endl << "The unsorted array is: " << endl;
    for (i= 0; i < n; i++)
    {
        cout << A[i] << " ";
    }


    bubble_sort(A,n);
    cout << endl << "The sorted array is: " << endl;
    for (i= 0; i < n; i++)
    {
        cout << A[i] << " ";
    }
}
