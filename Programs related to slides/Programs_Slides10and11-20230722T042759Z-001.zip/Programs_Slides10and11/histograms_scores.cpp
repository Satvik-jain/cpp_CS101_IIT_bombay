#include<iostream>
using namespace std;

void input_array_values (float*scores, int n)
{
    for(int i = 0; i< n; i++) cin >> scores[i];
}

void print_array_values (float *hist, int n)
{
    for(int i = 0;i < n; i++) cout << hist[i] << " ";
}

int main()
{
    float scores[100],hist[10];
    int n,i;

    cout << "enter the number of students: ";
    cin >> n;

    cout << "enter the scores of each student: ";
    input_array_values(scores,n);

    for(i=0;i<10;i++) hist[i] = 0; // histogram with 10 �bins� or intervals

    for(i=0;i<n;i++)
    {
        if (scores[i] <= 10) hist[0]++;
        else if (scores[i] <= 20) hist[1]++;
        else if (scores[i] <= 30) hist[2]++;
        else if (scores[i] <= 40) hist[3]++;
        else if (scores[i] <= 50) hist[4]++;
        else if (scores[i] <= 60) hist[5]++;
        else if (scores[i] <= 70) hist[6]++;
        else if (scores[i] <= 80) hist[7]++;
        else if (scores[i] <= 90) hist[8]++;
        else hist[9]++;
    }

    print_array_values(hist,10);
}
