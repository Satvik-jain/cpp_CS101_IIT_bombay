#include <iostream>
using namespace std;

void printArray (int*A, int n)
{
    for(int i = 0;i < n;i++) cout << A[i] << " ";
}

void swap (int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

void insertion_sort (int *A, int n)
{
    int i, j;

    for (i=1;i < n;i++)
    {
        j = i;

        while (j > 0 && A[j-1] > A[j])
        {
            swap (&A[j],&A[j-1]);
            j = j - 1;
        }
    }
}

int main()
{
    int n,i;
    int A[100];

    cout << "Enter the number of numbers: "; cin >> n;

    for (i=0;i<n;i++)
    {
        cout << endl << "Enter the next number: "; cin >> A[i];
    }

    insertion_sort(A,n);

    cout << endl;
    printArray(A,n);
}
