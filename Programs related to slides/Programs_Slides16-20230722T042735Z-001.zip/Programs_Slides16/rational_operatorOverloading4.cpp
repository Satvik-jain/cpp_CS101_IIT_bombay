#include<iostream>
using namespace std;

class Rational{
public:
Rational () { num =0; den = 1;}

Rational(int x, int y){ // default constructor
        num = x; den = y;
}

Rational(const Rational& r){ // copy constructor
        num = r.num;
        den = r.den;
}

Rational& operator=(const Rational& r){ // assignment operator
        num = r.num;
        den = r.den;
        return *this;
}

Rational operator+(const Rational& r){
Rational z;
z.num = num*r.den+den*r.num; z.den = den*r.den;
return z;
}

Rational operator!() {int temp = num; num = den; den = temp; return *this;}

Rational operator++() {num += den; return *this;}

int operator[](int i){ 
if (i == 0) return num;
else return den;
}

void print(){ cout << endl << num << " " << den;}

// other declarations go here
private:
int num;
int den;
};


int main()
{
	Rational x(5,7);
	x = !x;
	x.print();
	x = ++x;
	x.print();

	int z1 = x[0];
	int z2 = x[1];
	cout << endl << z1 << " " << z2;
}
