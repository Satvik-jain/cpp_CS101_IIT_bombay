#include<iostream>
using namespace std;

class Rational
{
public:
	Rational () { num = 0; den = 1;}
	Rational(int n, int d) { num =n; den = d;reduce(); }

	Rational(const Rational& r) {num = r.num; den = r.den; cout << "copy constructor" << endl;}

	void print() { cout << num << "/" << den; }

private:
	int num, den;
	int gcd(int m, int n) { if (m%n==0) return n; return gcd(n,m%n); }
	void reduce() { int g = gcd(num, den); num /= g; den /= g; }
};

Rational f(Rational r)
{
	Rational s = r;
	return s;
}


int main()
{
	Rational x(22,7);
	Rational y(x);
	Rational z(f(y));
}
