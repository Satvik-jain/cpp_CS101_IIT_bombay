#include <iostream>
using namespace std;

class Rational 
{
public:
Rational() { num = 0; den = 1; }
Rational(int n) { num = n; den = 1; }
Rational(int n, int d) { num = n; den = d; }
void print() { cout << num << "/" << den; }

private:
int num, den;
};

int main(){
Rational x, y(4), z(22,7);
cout << "x = " ; x.print(); cout << endl;
cout << "y = " ; y.print(); cout << endl;
cout << "z = "; z.print(); cout << endl;
}

