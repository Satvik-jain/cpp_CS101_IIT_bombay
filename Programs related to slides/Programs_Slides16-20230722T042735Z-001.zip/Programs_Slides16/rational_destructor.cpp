#include<iostream>
using namespace std;

class Rational {
public:
Rational() { cout << "OBJECT IS BORN.\n"; }
~Rational() { cout << "OBJECT DIES.\n"; }
private:
int num, den;
};

int main()
{
	{
		Rational x; // beginning of scope for x
		cout << "Now x is alive.\n";
	} // end of scope for x
	cout << "Now between blocks.\n";
	{
		Rational y;
		cout << "Now y is alive\n";
	}
}
