#include <iostream>
using namespace std;

class Rational {
public: 
void assign(int, int);
double convert(); 
void invert(); 
void print(); 
private: int num, den;
};

int main(){
Rational x;
x.assign(22,7);
cout << "x = "; x.print();
cout << " = " << x.convert(); cout << endl;
x.invert();
cout << "l/x = "; x.print(); cout << endl;
}


void Rational:: assign(int numerator, int denominator)
{
	num = numerator;
	den = denominator;
}
	
double Rational::convert()
{
	return double(num)/den;
}

void Rational::invert()
{
	int temp = num;
	num = den;
	den = temp;
}

void Rational::print()
{
	cout << num << " " << den;
}
