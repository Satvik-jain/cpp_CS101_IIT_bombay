#include<iostream>
using namespace std;

class MyMatrix
{
public:
	MyMatrix (int n1, int n2)
	{
		nr = n1;
		nc = n2;
		data = allocate_2d(nr,nc);
		for(int i=0;i<nr;i++)
		{
			for(int j=0;j<nc;j++)
			{
				data[i][j] = 0;
			}
		}
	}

	MyMatrix (const MyMatrix& r)
	{
		cout << endl << "CC";
		nr = r.nr; nc = r.nc;
		data = allocate_2d(nr,nc);

		for(int i=0;i<nr;i++)
		{
			for(int j=0;j<nc;j++)
			{
				data[i][j] = r.data[i][j];
			}
		}
	}

	void inputMatrix ()
	{
		for(int i=0;i<nr;i++)
		{
			for(int j=0;j<nc;j++)
			{
				cout << "enter value at index " << i << "," << j << ": ";
				cin >> data[i][j];
			}
		}
	}

	void printMatrix ()
	{
		for(int i=0;i<nr;i++)
		{
			for(int j=0;j<nc;j++)
			{
				cout << data[i][j] << " ";
			}
			cout << endl;
		}
	}

	~MyMatrix()
	{
		cout << "DD" << endl;
		deallocate_2d(data,nr,nc);
	}


	MyMatrix& operator=(const MyMatrix& r){ // assignment operator
	        nc = r.nc;
        	nr = r.nr;
		cout << "AE" << endl;

		for(int i=0;i<nr;i++)
		{
			for(int j=0;j<nc;j++)
			{
				data[i][j] = r.data[i][j];
			}
		}
	        return *this;
	}



	void operator+=(const MyMatrix& z)
	{
		if (nr != z.nr || nc != z.nc) { cout << "Incompatible sizes" ; }

		for(int i=0;i<nr;i++)
		{
			for(int j=0;j<nc;j++)
			{
				data[i][j] = data[i][j] + z.data[i][j];
			}
		}
	}


	MyMatrix operator+(const MyMatrix& z)
	{
		if (nr != z.nr || nc != z.nc) { cout << "Incompatible sizes" ; }
		MyMatrix s(nr,nc);
		for(int i=0;i<nr;i++)
		{
			for(int j=0;j<nc;j++)
			{
				s.data[i][j] = data[i][j] + z.data[i][j];
			}
		}
		return s;
	}


private:
	int nr, nc, **data;

	int **allocate_2d (int n1, int n2)
	{
		int **A = new int*[n1]; // array of n1 int* variables
		for(int i=0;i<n1;i++)
		{
			A[i] =  new int [n2]; // array of n2 int variables
		}
		return A;
	}

	void deallocate_2d (int **A, int n1, int n2)
	{
		for(int i=0;i<n1;i++)
		{
			delete [] A[i]; // array of n2 int variables
		}
		delete[] A;
	}
};

int main()
{
	int nr, nc;
	cout << "enter the number of rows and columns: "; 
	cin >> nr >> nc;

	MyMatrix m1(nr,nc);
	m1.inputMatrix();
	m1.printMatrix();


	MyMatrix m2(nr,nc);
	m2.inputMatrix();
	m2.printMatrix();


	MyMatrix m3(nr,nc);
	m3 = m1 + m2;
	m3.printMatrix();
}
