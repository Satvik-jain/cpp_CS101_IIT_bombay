#include<iostream>
using namespace std;

class Rational
{
public:
Rational(int n, int d) { num = n; den = d; reduce(); }
void print() { cout << num << "  "; cout << den << endl;}

private:
int num, den;
int gcd(int j, int k) { if (j%k==0) return k; return gcd(k,j%k); }
void reduce() { int g = gcd (num, den); num /= g; den /= g;}
};

int main()
{
	Rational x(100,360);
	x.print();
}
