#include<iostream>
using namespace std;

class Rational
{
public:
	Rational(int n, int d) { num =n; den = d;reduce(); }

	Rational(const Rational& r) {num = r.num; den = r.den; }

	void print() { cout << num << "/" << den; }

private:
	int num, den;
	int gcd(int m, int n) { if (m%n==0) return n; return gcd(n,m%n); }
	void reduce() { int g = gcd(num, den); num /= g; den /= g; }
};


int main()
{
	Rational x(100,360);
	Rational y(x);
	cout << "x = "; x.print(); 
	cout << ", y = "; y.print();
}
