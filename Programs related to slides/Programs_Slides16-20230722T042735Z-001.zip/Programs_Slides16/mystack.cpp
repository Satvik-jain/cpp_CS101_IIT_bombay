#include <iostream>
#define INVALID -10000
using namespace std;

class MyStack
{
	private:
	int top;
	int size; // if a stack is implemented using dynamic allocation, you should store the size
	int *A;

	public:
	bool isEmpty() {return (top==-1);}
	bool isFull() {return (top > -1 && top==size-1);}
	void push (int q) 
	{ 
		if (!isFull()) A[++top] = q;
		else cout << endl << "stack is full";
	}
	int pop () 
	{
		if (!isEmpty()) {top--;  return A[top+1];}
		return INVALID;
	}
	int getTop() {return top;}
	MyStack() {top=-1; A = NULL; size = 0;} 
	MyStack(int n) { top=-1; size = n; A = new int[size];}
	~MyStack() { delete [] A; top=-1; size =0; A = NULL;}
};

int main()
{
	int s,q;
	cout << "enter size of the stack";
	cin >> s;

	MyStack m1(s);

	while (true)
	{
		cout << endl;
		cout << "Choose one of the following: (1) push, (2) pop, (3) exit";
		int choice;
		cin >> choice;

		if (choice == 3) break;
		if (choice == 1) 
		{ 
			cout << "enter the element to push:"; 
			cin  >> q;
			m1.push(q);
			cout << " the top of the stack is " << m1.getTop();
		}
		if (choice == 2)
		{
			q = m1.pop();
			if (q != INVALID)
			{
				cout << endl << "the element popped off is " << q;
			}
			else
			{
				cout << endl << "The stack is empty"; 
			}
			cout << " the top of the stack is " << m1.getTop();
		}
	}

}
