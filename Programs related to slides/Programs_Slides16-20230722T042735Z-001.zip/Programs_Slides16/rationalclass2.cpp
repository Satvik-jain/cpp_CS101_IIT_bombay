#include <iostream>
using namespace std;

class Rational {
public:

void assign (int n, int d) {num = n; den = d; };

void print() { cout << num << "/" << den; }

void invert()
{
	int temp = num;
	num = den;
	den = temp;
}

double convert()
{
	return double(num)/den;
}

private: int num, den;
};

int main(){
Rational x;
x.assign(22,7);
cout << "x = "; x.print();
cout << " = " << x.convert(); cout << endl;
x.invert();
cout << "1/x = "; x.print(); cout << endl;
}


