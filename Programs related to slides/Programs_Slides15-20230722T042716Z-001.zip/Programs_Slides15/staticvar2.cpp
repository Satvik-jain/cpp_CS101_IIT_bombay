#include <iostream>
using namespace std;

int main(){
    int i;

     for(int j=0;j<2;j++)
	{
    for(i=0;i<10;i++)
	{
		static int a = 10;
		a++;
		cout << a << endl;
	}
	}

    return 0;
}

