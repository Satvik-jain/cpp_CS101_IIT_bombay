#include<iostream>
using namespace std;

void demo_static_variable()
{
    // static variable
    static int count = 0;
    cout << count << " ";

    // value is updated and
    // will be carried to next
    // function calls
    count++;
}

int main()
{
    for (int i=0; i<5; i++)
        demo_static_variable();
    return 0;
}
