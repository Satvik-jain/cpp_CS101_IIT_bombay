#include <iostream>
using namespace std;

void add(int a, int b){ cout << "Addition is " << a+b; }
void subtract(int a, int b){ cout << "Subtraction is " << a-b; }
void multiply (int a, int b){ cout << "Product is " << a*b; }
int main() {
// fun_ptr_arr is an array of function pointers
void (*fun_ptr_arr[])(int, int) = {add, subtract, multiply};
unsigned int ch, a = 15, b = 10;
cout << "enter your choice (0): add, (1): subtract, (2): multiply"; cin >> ch;
if (ch > 2) return 0;
(*fun_ptr_arr[ch])(a, b);
 return 0;
}
