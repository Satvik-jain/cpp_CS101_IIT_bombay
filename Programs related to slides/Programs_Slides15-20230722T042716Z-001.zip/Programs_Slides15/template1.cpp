#include<iostream>
using namespace std;

template <typename T>
T myabs(T x)
{
	if (x >= 0) return x; 
	return -x;
}

int main()
{
	int a = myabs(-10);
	float b = myabs(-1.234);
	double c = myabs(4.44);

	cout << a << " " << b << " " << c;
}
