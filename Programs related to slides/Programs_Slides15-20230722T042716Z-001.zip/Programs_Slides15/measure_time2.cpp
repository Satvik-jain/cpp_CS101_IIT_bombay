#include<iostream>
#include<ctime>
using namespace std;
void myfun(int n){
        int i,j;
        int a;

        for(i=0;i<n;i++){
                for(j=0;j<n;j++){
                        a = i+j+i*j;
                }
        }
}
int main(){
    // clock_t clock(void) returns the number of clock ticks elapsed since the program was launched
    clock_t start, end;

    // Recording the starting clock tick
    start = clock();

    myfun(1000);

    // Recording the end clock tick.
    end = clock();

    // Calculating total time taken by the program.
    double time_taken = double(end - start) / double(CLOCKS_PER_SEC);
    cout << "Time taken by program is : " << time_taken << " sec.";
}
