#include<iostream>
using namespace std;

// Returns the sum f(0) + f(1) + f(2) + . . . + f(n-1):
int sum(int (*pf)(int k), int n) {
int s = 0;
for (int i = 1; i <= n; i++)
s += (*pf) (i);
return s;
}
int square(int k) {
return k*k;
}
int cube(int k){
return k*k*k;
}

int main () {
cout << sum(square,4) << endl; //1+4+9+16
cout << sum(cube,4) << endl;
}
