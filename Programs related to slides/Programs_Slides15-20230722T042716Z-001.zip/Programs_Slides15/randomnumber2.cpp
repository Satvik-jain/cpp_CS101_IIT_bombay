#include <cstdlib>
#include <ctime>
#include <iostream>
using namespace std;
int main() {
    time_t t;
     time (&t);
     srand(t);
// This program will now create a 
// different sequence of random numbers // on every program run as the seed was // set equal to the current time
    for (int i = 0; i < 5; i++)
        cout << rand() << " ";

    return 0;
}

