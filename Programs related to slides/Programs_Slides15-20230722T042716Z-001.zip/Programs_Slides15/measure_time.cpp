#include<iostream>
#include<ctime>
using namespace std;
void myfun(int n){
        int i,j;
        int a;

        for(i=0;i<n;i++){
                for(j=0;j<n;j++){
                        a = i+j+i*j;
                }
        }
}
int main(){
        time_t start, end;
        int n = 50000;

        time(&start);

        myfun(n);

        time (&end);

        double time_exec = double(end-start);
        cout << time_exec << " secs";
}
