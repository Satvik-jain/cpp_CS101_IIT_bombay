#include<iostream>
using namespace std;

template <typename T>
void tswap(T& x, T& y){
T temp = x;
x = y;
y = temp;
}

int main()
{
	int a = 20, b = 30;
	tswap(a,b);
	cout << a << " " << b << endl;

	float c = 2.01, d = 3.22;
	tswap(c,d);
	cout << c << " " << d << endl;

	double x = 5.55, y = 3.33;
	tswap(x,y);
	cout << x << " " << y;

}
