#include<iostream>
using namespace std;

template <typename T, typename U>
T addval(T& x, U& y){
	return x+y;
}

int main()
{
	int a = 20, b = 30;
	cout << a << " " << b << " " << addval(a,b) << endl;

	float c = 2.01, d = 3.22;
	cout << c << " " << d << " " << addval(c,d) << endl;

	int x = 5; double y = 3.22;
	cout << x << " " << y << " " << addval(x,y);

}
