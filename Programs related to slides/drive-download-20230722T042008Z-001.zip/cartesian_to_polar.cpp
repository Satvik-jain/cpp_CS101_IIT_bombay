#include<iostream>
#include<cmath>
using namespace std;

void cartesianToPolar (double x, double y, double &r, double &theta){
	r = sqrt(x*x + y*y);
	theta = atan(y/x);
}

int main (){
double x = 1.0, y = 1.0, theta, r;
cartesianToPolar (x,y,r,theta);
cout << theta << " " << r;
}
