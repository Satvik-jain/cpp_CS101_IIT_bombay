#include<iostream>
using namespace std;

void swapV (int a, int b){
int temp = a; a = b; b = temp; return;
}

void swapR (int& a, int& b){
int temp = a; a = b; b = temp; return;
}
// int &a, int &b is also valid // syntax


int main () {
int x = 10, y = 20;

swapV(x,y);
cout << x <<" "<<y<<endl;

swapR(x,y);
cout << x <<" "<<y;


return 0;
}
