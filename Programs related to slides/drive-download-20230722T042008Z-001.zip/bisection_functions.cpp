#include<iostream>
using namespace std;

double f (double x) { return x*x*x-5; } // function declaration
double bisection_root (double xL, double xR, double epsilon){
// initial interval is given by [xL, xR], given as input
// precision of the root�s value is also given as input
bool flagL, flagR, flagM; double xM;
flagL = f(xL) > 0; flagR = f(xR) > 0; // signs of f(xL) and f(xR)
if (flagL != flagR)
{
	while (xR - xL > epsilon) // until reqd. precision is reached
	{
		xM = (xR+xL)/2; // interval midpoint
		flagM = f(xM) > 0;
if (flagM != flagL) xR = xM; // signs of f(xM) and f(xL)
else if (flagM != flagR) xL = xM;
	}
}
return xL;
}

int main (){
double xL = 1, xR = 2, epsilon=0.001;
double rootval;

rootval = bisection_root(xL,xR,epsilon);
cout << rootval;
return 0;
}
