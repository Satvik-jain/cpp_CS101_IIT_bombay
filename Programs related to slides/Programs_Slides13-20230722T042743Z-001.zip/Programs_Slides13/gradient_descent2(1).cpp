#include<simplecpp>

main_program{
//Write your code here
// function f(x) = (x-3)^2+5;
double x, xnew, fx, fxnew, dfx=10000;
double epsilon = 0.001;
double stepsize;
cout << "enter the initial guess: "; cin >> x;

dfx = 2*(x-3);
fx = (x-3)*(x-3)+5;
stepsize = 0.05;
while (fabs(dfx) > epsilon)
{
    stepsize = 2;

    while (1)
    {
        xnew = x - stepsize * dfx;
        fxnew = (xnew-3)*(xnew-3)+5;
        if (fxnew < fx)
        {
            x = xnew;
            break;
        }
        else
        {
            stepsize = stepsize*0.9;
        }
    }

    fx = (x-3)*(x-3)+5;
    dfx = 2*(x-3);
    cout << x << " " << fx << " " << dfx << endl;
    wait (0.5);
}
cout << "The minimum is at " << x;
}
