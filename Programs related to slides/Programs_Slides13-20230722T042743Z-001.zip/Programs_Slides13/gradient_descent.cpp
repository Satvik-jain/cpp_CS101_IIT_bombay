#include<simplecpp>

main_program{
//Write your code here
// function f(x) = (x-3)^2+5;
double epsilon = 0.001; // desired precision
double x, fx, dfx=epsilon+10; // to ensure that the while loop is entered
double stepsize;
cout << "enter the initial guess: "; cin >> x;

fx = (x-3)*(x-3)+5;
dfx = 2*(x-3);
cout << x << " " << fx << " " << dfx << endl;

stepsize = 0.05;
while (fabs(dfx) > epsilon)
{
    x = x - stepsize * dfx;
    fx = (x-3)*(x-3)+5;
    dfx = 2*(x-3);
    cout << x << " " << fx << " " << dfx << endl;
    wait (0.5);
}
cout << "The minimum is at " << x;
}
