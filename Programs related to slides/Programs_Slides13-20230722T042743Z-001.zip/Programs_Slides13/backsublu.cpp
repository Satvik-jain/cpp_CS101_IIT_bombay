#include <iostream>
#define MAX 100
using namespace std;

// program for Gaussian elimination method for solutions to 
// linear simultaneous equations
// The backsubstitution method  is also implemented for solutions to systems
// with upper triangular matrix

void GaussElim (float A[][MAX], float *b, int n)
{
	int i,j,k;
	float ratio;

	for(i=0;i<n-1;i++)
	{
		if (A[i][i] == 0) {cout << "mathematical error"; return;}
		for(j=i+1;j<n;j++)
		{
			ratio = A[j][i]/A[i][i];
			for(k=0;k<n;k++)	
			{
				A[j][k] = A[j][k]-ratio*A[i][k];
			}
			b[j] = b[j]-ratio*b[i];
		}

	}
}

void print2darray(float A[][MAX], int n1, int n2)
{
	int i,j;
	for(i=0;i<n1;i++)
	{
		for(j=0;j<n2;j++)
		{
			cout << A[i][j] << " ";
		}
		cout << endl;
	}
}

void backsub_LU (float A[][MAX], float *b, float *x, int n){
	int i,j;

	for(i=n-1; i>= 0; i--){
	if (A[i][i] == 0) { cout << "matrix is singular"; return;}
	x[i] = b[i];
	for(j=i+1;j<=n-1;j++){
		x[i] = x[i] - A[i][j]*x[j];
	}
	x[i] = x[i]/A[i][i];
	}
}

int main()
{
	int n,i,j;
	float A[MAX][MAX],x[MAX],b[MAX];

	cout << "enter n: ";
	cin >> n;


	cout << endl << "enter the values in A" << endl;
	for(i=0;i<n;i++)
	{
			for(j=0;j<n;j++)	
		{
			cout << "enter value at (" << i << "," << j << ")";
			cin >> A[i][j];
		}
	}

	cout << endl << "enter the values of b: ";
	for(i=0;i<n;i++) cin >> b[i];

	GaussElim(A,b,n);

	cout << endl << "The array A after adjustment is: " << endl;
	print2darray(A,n,n);
	cout << endl << "The array b after adjustment is: " << endl;
	for(i=0;i<n;i++) cout << b[i] << " ";

	backsub_LU (A,b,x,n);

	cout << endl << "x is:" << endl;
	for(i=0;i<n;i++) cout << x[i] << " ";
}
